package org.quarkusgetdata.service;

import org.quarkusgetdata.entity.VehicleOwner;

public interface VehicleOwnerService{

     VehicleOwner findPersonalDetails(Integer vehicleNumber) ;

}
